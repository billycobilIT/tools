async function getTelegramGroup() {
    let link = "https://t.me/toolsforinstagram"
    console.log("Welcome to the TFI Telegram community!");
    console.log(link.cyan);
    return link;
}

module.exports = getTelegramGroup;